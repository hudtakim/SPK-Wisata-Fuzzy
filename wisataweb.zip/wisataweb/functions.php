<?php
	$dbhost = "localhost";
	$dbuser = "root";
	$pass = "";
	$db = "wisata_tegal_db";
	$conn = mysqli_connect($dbhost, $dbuser, $pass, $db ) or die ("gagal masuk database");

?>